//
//  DyFramework.swift
//  DyFramework
//
//  Created by Krishna Kushwaha on 12/01/21.
//

import Foundation
public class TestDynamic {
    
    public static func sayHi() -> String {
        return "Hi from Dynamic Framework!"
    }
    
  
}
