//
//  DySecondF.swift
//  DySecondF
//
//  Created by Krishna Kushwaha on 12/01/21.
//

import Foundation
import UIKit
public class DySecondF {
    var navigationCon: UINavigationController?
  //  var completionHandler : (([String: Any]? ,String) -> ())?

    
    public init(item : String!,nav : UINavigationController?){
        self.navigationCon =  nav
    }
    public func startViewController()-> UIViewController{
        let bundle = Bundle(for: ViewController.self)
               let vc = ViewController(nibName: "ViewController", bundle: bundle) as ViewController
               return vc
    }
    
    
    
    
}
