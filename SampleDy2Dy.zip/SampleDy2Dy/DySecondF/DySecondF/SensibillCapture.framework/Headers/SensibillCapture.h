//
//  SensibillCapture.h
//  SensibillCapture
//
//  Created by Steven Andrews on 2020-04-27.
//  Copyright © 2020 Sensibill. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SensibillCapture.
FOUNDATION_EXPORT double SensibillCaptureVersionNumber;

//! Project version string for SensibillCapture.
FOUNDATION_EXPORT const unsigned char SensibillCaptureVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SensibillCapture/PublicHeader.h>
