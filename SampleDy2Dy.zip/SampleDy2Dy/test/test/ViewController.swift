//
//  ViewController.swift
//  test
//
//  Created by Krishna Kushwaha on 12/01/21.
//

import UIKit
import DySecondF
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let erp =  DySecondF(item : "", nav: navigationController)
        let vc =    erp.startViewController ()
        self.navigationController?.pushViewController(vc, animated: false)
    }


}

